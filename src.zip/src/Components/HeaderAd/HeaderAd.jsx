import React from 'react'
import './HeaderAd.css'

const HeaderAd = () => {
    return (
        <section className='section'>
        <p >Get 10% on your first Purchase. Sign Up to Mailing List</p>
       </section>
    )
}

export default HeaderAd
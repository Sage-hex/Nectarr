import React from 'react'
import './Auth.css'

const BuyersLogin = () => {
  return (
    <div className='Login'></div>
  )
}

export default BuyersLogin
import React from 'react'

const RessetPasword = () => {
  return (
    <div>RessetPasword</div>
  )
}

export default RessetPasword
import React from 'react'

const ForgetPassword = () => {
  return (
    <div>ForgetPassword</div>
  )
}

export default ForgetPassword
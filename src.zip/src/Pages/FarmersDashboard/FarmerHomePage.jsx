import React from 'react'

const FarmerHomePage = () => {
  return (
    <div>FarmerHomePage</div>
  )
}

export default FarmerHomePage
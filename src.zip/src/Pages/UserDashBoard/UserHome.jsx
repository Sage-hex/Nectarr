import React from 'react'

const UserHome = () => {
  return (
    <div>UserHome</div>
  )
}

export default UserHome